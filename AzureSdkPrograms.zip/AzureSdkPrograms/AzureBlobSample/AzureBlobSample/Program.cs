﻿using Azure.Identity;
using Azure.Storage;
using Azure.Storage.Blobs;
using System.IO;

// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");

const string conStr = "BlobEndpoint=https://anwesastorage.blob.core.windows.net/;QueueEndpoint=https://anwesastorage.queue.core.windows.net/;FileEndpoint=https://anwesastorage.file.core.windows.net/;TableEndpoint=https://anwesastorage.table.core.windows.net/;SharedAccessSignature=sv=2022-11-02&ss=bfqt&srt=sco&sp=rwdlacupiytfx&se=2024-02-20T14:51:07Z&st=2024-02-20T06:51:07Z&spr=https,http&sig=uQDCgFVHJAu6VXFgkHYRohYry0ZFZBCQGuU5xi0yQa8%3D";
var storageClient = new BlobContainerClient(conStr, "images");//We write the container name
var blobs = storageClient.GetBlobs();

foreach(var item in blobs)
{
    Console.WriteLine($"{item.Name} -" + $"{item.Properties.ContentLength}");
}

const string filePath = @"C:\Users\ANWCHAKR\Desktop\MODULE 1\AzureSdkPrograms\MyFile.txt";

string fileName = Guid.NewGuid().ToString();

//var blobClient = storageClient.GetBlobClient("MyUploadedFile.txt");

//var blobClient = storageClient.GetBlobClient($"{fileName}.txt");

var fileInfo = new FileInfo(filePath);

var blobClient = storageClient.GetBlobClient($"{fileName}_" +
    $"{fileInfo.Name}_" +
    $"{DateTime.Now.ToString("ddMMyyyyhhmmss")}" +
    $"{fileInfo.Extension}");


blobClient.Upload(filePath);
