﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CaseStudyReq1
{
    internal class Class1
    {
        private string productCode;
        private string productName;
        private double productPrice;
        private char categoryCode; 

        private static int prodCounter = 100;

        public string ProductCode
        {
            set
            {
                productCode = value;
            }

            get
            {
                return productCode;
            }
        }

        public string ProductName
        {
            set
            {
                productName = value;
            }

            get
            {
                return productName;
            }
        }

        public double ProductPrice
        {
            set
            {
                productPrice = value;
            }

            get
            {
                return productPrice;
            }
        }

        public char CategoryCode
        {
            set
            {
                categoryCode = value;
            }

            get
            {
                return categoryCode;
            }
        }

        private string generateProductCode()
        {
            //int count;
            //count = ++Class1.prodCounter; //101
            //string count1 = count.ToString();
            //string p = "";
            //p = count1 + p;
            //p = p + categoryCode;
            //productCode = p;
            //productCode = string.Empty;
            //productCode = ++Class1.prodCounter.ToString();
            //productCode += categoryCode;
            //return productCode;
            //productCode = count1 + categoryCode;
            //Console.WriteLine($"productCode = {productCode}");

            //string productCode = "";

            return $"{categoryCode}{++Class1.prodCounter}"; 
        }

        public Class1(string productName, double productPrice, char categoryCode) 
        {
            this.productName = productName;
            this.productPrice = productPrice;
            this.categoryCode = categoryCode;
            this.productCode = generateProductCode();
        }

        public Class1(string productName, double productPrice) : this(productName, productPrice, 'E')
        {
            //this.productName= productName;
            //this.productPrice = productPrice;
            //this.productCode = generateProductCode();
        }

        public string getProductDetails()
        {
            return $"Code - {productCode}, Name - {productName}, Price - {productPrice}, Category - {categoryCode}";
        }

        //public void Display()
        //{
          //  generateProductCode();
        //}

        //public Class1(string productName,  double productPrice, char categoryCode)
        //{

        //}

        //public Class1(string productName, double productPrice)
        //{
        //    productName = generateProductCode();
        //    this.productPrice = productPrice;
        //}

        //public string getProductDetails()
        //{
        //    return 
        //}

    }
}
