﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");

using CaseStudyReq1;

Class1 obj = new Class1("Laptop", 45000.00, 'E');
Console.WriteLine(obj.getProductDetails());
