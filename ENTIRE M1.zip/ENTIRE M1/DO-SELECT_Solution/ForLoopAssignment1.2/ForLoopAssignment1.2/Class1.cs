﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForLoopAssignment1._2
{
    // DO - SELECT QUESTIONS
    internal class Class1
    {
        int a, b;
        int sum = 0;

        public void GetDetails()
        {
            Console.WriteLine("Enter two numbers");

            a = Convert.ToInt32(Console.ReadLine());
            b = Convert.ToInt32(Console.ReadLine());    
        }

        public void Cal()
        {
            sum = a + b;
            Console.WriteLine(sum);
        }
    }
}
