﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");

using ForLoopAssignment1._2;

Class1 obj = new Class1();
obj.GetDetails();
obj.Cal();
