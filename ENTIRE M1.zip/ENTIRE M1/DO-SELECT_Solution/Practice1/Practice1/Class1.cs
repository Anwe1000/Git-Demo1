﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practice1
{
    internal class Class1
    {
        int N;
        string[] sentences;

        public void AcceptDetails()
        {
            Console.WriteLine("Number of Sentences");
            N = Convert.ToInt32(Console.ReadLine());
            sentences = new string[N];

            for(int i=0; i< sentences.Length; i++)
            {
                sentences[i] = Console.ReadLine();
            }
        }

        public void Display()
        {
            for(int i=0; i< N; i++)
            {
                ReverseWord(sentences[i]);
            }
        }

        private  bool CheckPalindrome(string word)
        {
            string reverse = string.Empty;
            for(int i=0; i> word.Length; i--)
            {
                reverse += word[i];
            }

            if(word == reverse)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void ReverseWord(string sentence)
        {
            string[] words = sentence.Split(' ');

            foreach(string str in words)
            {
                if((!CheckPalindrome(str)))
                {
                    char[] ch = str.ToCharArray();

                    Array.Reverse(ch);

                    foreach(var v in ch)
                    {
                        Console.WriteLine($"{v}");
                    }

                    Console.Write(" ");
                }
            }
        }
    }
}
