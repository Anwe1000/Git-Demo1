﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practice1
{
    internal class Class2
    {
        Stack<string> myplayers = new Stack<string>();


        public void AddPlayer(string name)
        {

            //string name = null;
            //name = null;

            //Console.WriteLine($"Enter the names of Player: ");

            //for (int i = 0; i < 5; i++)
            //{
               // name = Console.ReadLine();
                //if (name != null)
                //{
                    myplayers.Push(name);
                //}
            //}
        }

        public string GetAllPlayers()
        {
            string e = "";

            foreach(string s in myplayers)
            {
              if(s != null)
                {
                    e += s + ",";
                }
            }

            char[] ch = e.ToCharArray();

            string r = "";

            for(int i=0; i< ch.Length-1; i++)
            {
                if(r != null)
                {
                    r += ch[i];
                }
            }
            return r;
        }

        public string GetPlayer()
        {
            string s = myplayers.Peek();
            return s;
        }
        
        public void RemovePlayer()
        {
            Console.WriteLine($"Removed Player : {myplayers.Pop()}");
        }

        //public void Result()
        //{
        //    Console.WriteLine(GetPlayer());
        //    Console.WriteLine(GetAllPlayers());
        //}
    }
}
