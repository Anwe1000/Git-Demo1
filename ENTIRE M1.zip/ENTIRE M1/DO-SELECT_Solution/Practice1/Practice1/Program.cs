﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using Practice1;

//Class1 obj = new Class1();
//obj.AcceptDetails();
//obj.Display();


Class2 c =  new Class2();
c.AddPlayer("Player 1");
c.AddPlayer("Player 2");
c.AddPlayer("Player 3");
c.AddPlayer("Player 4");
//c.Result();
Console.WriteLine(c.GetAllPlayers());
c.RemovePlayer();