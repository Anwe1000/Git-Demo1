﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortAnArray_DoSelect
{
    internal class Class1
    {
        int[] arr;
        int N;

        public void GetDetails()
        {
            Console.WriteLine("Enter the size");
            N = Convert.ToInt32(Console.ReadLine());
            arr = new int[N];

            for(int i=0; i<N; i++)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }
        }

        public void Details()
        {
            Console.WriteLine("Enter A for Ascending or D for Descending");
            char ch;
            ch = Convert.ToChar(Console.ReadLine());

            switch (ch)
            {
                case 'A':

                    Array.Sort(arr);

                    break;

                case 'D':

                    Array.Sort(arr);
                    Array.Reverse(arr);

                    break;

                default:
                    Console.WriteLine("Invalid Input");

                    break;
            }

            foreach (int i in arr)
            {
                Console.WriteLine(i);
            }
        }
    }
}
