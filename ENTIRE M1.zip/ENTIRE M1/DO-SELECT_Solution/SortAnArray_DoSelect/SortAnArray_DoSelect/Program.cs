﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");

using SortAnArray_DoSelect;

Class1 obj = new Class1();  
obj.GetDetails();
obj.Details();
