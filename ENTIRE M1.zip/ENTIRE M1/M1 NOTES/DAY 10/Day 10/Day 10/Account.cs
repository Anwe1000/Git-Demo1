﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_10
{
    internal class Account
    {
        string name;
        double balance;
        double amount;

        public void GetDetails()
        {
            Console.WriteLine("Enter the name");
            name = Console.ReadLine();

            Console.WriteLine("Enter the total balance");
            balance = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter the amount you want to withdraw");
            amount = Convert.ToDouble(Console.ReadLine());  
        }

        public void DisplayDetails()
        {
            if(amount > balance)
            {
                try
                {
                    throw new CustomClassException("Insufficient Balance!");
                }

                catch(Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            else
            {
                balance = balance - amount;
            }
        }
    }
}
