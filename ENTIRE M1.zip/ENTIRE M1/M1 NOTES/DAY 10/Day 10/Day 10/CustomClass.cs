﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_10
{
    internal class CustomClassException : Exception
    {
        public CustomClassException(string message) : base(message) 
        {
            
        }
    }
}
