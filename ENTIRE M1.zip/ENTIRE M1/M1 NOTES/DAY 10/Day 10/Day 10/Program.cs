﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using Day_10;


// CUSTOM CLASS EXCEPTION PROGRAM

//Account obj = new Account();
//obj.GetDetails();
//obj.DisplayDetails();


// TRY-CATCH PROGRAM

//TryCatchAcceptDetails tc = new TryCatchAcceptDetails();
//tc.DisplayDetails();
