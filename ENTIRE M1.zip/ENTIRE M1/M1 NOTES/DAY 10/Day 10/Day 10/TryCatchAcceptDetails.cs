﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_10
{
    internal class TryCatchAcceptDetails
    {
        int num1, num2;
        int result;

        public void AcceptDetails()
        {
            try
            {
                Console.WriteLine("Enter a number");
                num1 = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter another number");
                num2 = Convert.ToInt32(Console.ReadLine());
            }

            catch(FormatException fe)
            {
                Console.WriteLine("Enter a correct number");
                Console.WriteLine(fe.Message);
            }
        }

        private void Divide()
        {
            try
            {
                result = num1 / num2;
                Console.WriteLine($"The result is : {result}");
            }

            catch(DivideByZeroException de) 
            {
                Console.WriteLine("Divide by zero not possible");
                Console.WriteLine(de.Message);
            }
        }

        public void DisplayDetails()
        {
            AcceptDetails();
            Divide();
        }
    }
}
