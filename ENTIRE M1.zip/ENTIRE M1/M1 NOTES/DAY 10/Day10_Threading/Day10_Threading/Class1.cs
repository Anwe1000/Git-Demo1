﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Day10_Threading
{
    internal class Class1
    {
        public static void Display1()
        {
           for(int i=0; i< 50; i++)
            {
                Console.WriteLine($"Function 1 : {i}");
            }
        }

        public static void Display2()
        {
            for(int i=0; i< 50; i++)
            {
                Console.WriteLine($"Function 2 : {i}");
            }
        }
    }
}
