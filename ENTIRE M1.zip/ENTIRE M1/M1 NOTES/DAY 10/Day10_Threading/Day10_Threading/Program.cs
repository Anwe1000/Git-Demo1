﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");



using Day10_Threading;
using System.Threading;

//Class1 obj = new Class1();  
Thread.CurrentThread.Name = "Main Thread";
Console.WriteLine($"{Thread.CurrentThread.Name}");

Thread t1 = new Thread(Class1.Display1);
Thread t2 = new Thread(Class1.Display2);

t1.Start();
t2.Start();