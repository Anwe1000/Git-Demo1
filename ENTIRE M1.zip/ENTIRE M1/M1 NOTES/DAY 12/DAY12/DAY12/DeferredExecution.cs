﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAY12
{
    internal class DeferredExecution
    {
        string[] trainees = new string[4] {"Robert", "Wilson", "Wiley","Sam"};

        public void DisplayNames()
        {
            var names = from t in trainees
                        select t;

            foreach(string t in names)
            {
                Console.WriteLine(" "+t);
            }

            trainees[1] = "Aneesh";
            trainees[2] = "Rimli";

            Console.WriteLine();

            foreach(string t in names)
            {
                Console.Write(" "+t);
            }
        }
    }
}
