﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");

using DAY12;

DeferredExecution obj = new DeferredExecution();
obj.DisplayNames();

//Demo2 obj = new Demo2();
//obj.DisplayNamesWithS();
//obj.GroupBy();

//JoinsDemo jd = new JoinsDemo();
//jd.Display();