﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day13_DBMS
{
    internal class Class1
    {
        ColledeDBDataContext db;

        public Class1()
        {
            db = new ColledeDBDataContext();
        }

        public void GetAllStudent()
        {
            List<Student1> stds = db.Student1s.ToList();

            foreach (Student1 s in stds)
            {
                Console.WriteLine($"Id : {s.Id} Name : {s.NAME} Marks : {s.MARKS}");
            }
        }

        public void GetStudentById()
        {
            Console.WriteLine("Enter Id");
            int id = Convert.ToInt32(Console.ReadLine());

            Student1 std = (from a in db.Student1s
                            where a.Id == id
                            select a).Single();

            Console.WriteLine($"Id : {std.Id} Name : {std.NAME} Marks : {std.MARKS}");
        }

        public void AddNewStudent()
        {
            Console.WriteLine("Enter the Id");
            int id = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the name");
            string name = Console.ReadLine();

            Console.WriteLine("Enter Marks");
            int marks = Convert.ToInt32(Console.ReadLine());

            Student1 newstudent = new Student1()
            {
                Id = id,
                NAME = name,
                MARKS = marks
            };

            db.Student1s.InsertOnSubmit(newstudent);
            db.SubmitChanges();
        }

        public void UpdateMarks()
        {
            Console.WriteLine("Enter id");
            int id = Convert.ToInt32(Console.ReadLine());

            Student1 std = (from a in db.Student1s
                            where a.Id == id
                            select a).Single();

            if (std != null)
            {
                Console.WriteLine("Enter updated Marks");
                std.MARKS = Convert.ToInt32(Console.ReadLine());
                db.SubmitChanges();

                Console.WriteLine("Updated Marks");
            }
            else
            {
                Console.WriteLine("No student with id exists");
            }
        }

        public void DeleteStudent()
        {
            Console.WriteLine("Enter id");
            int id = Convert.ToInt32(Console.ReadLine());

            Student1 std = (from a in db.Student1s
                           where a.Id == id
                           select a).Single();

            if (std != null)
            {
                db.Student1s.DeleteOnSubmit(std);
                db.SubmitChanges();
                Console.WriteLine("Student Deleted Successfully");
            }
            else
            {
                Console.WriteLine("No student with id exists");
            }
            {
                
            }
        }
    }
    }

