Use AdventureWorks2019
Select * from HumanResources.Employee
Select BusinessEntityID, LoginID, JobTitle
from HumanResources.Employee
Select BusinessEntityID, LoginID, JobTitle
from HumanResources.Employee
Where JobTitle = 'Research and Development Manager'

Select * from HumanResources.Department

--Three types of Alias Names--

--Select 'Department Number' = DepartmentID,
--'Department Name' = Name--
--From HumanResources.Department--

------- OR -------------------
--Select DepartmentID 'Department Number', Name 'Department Name'--
--From HumanResources.Department--

Select 'snow' + 'ball'

Select Name + 'department comes under' + GroupName + 'group' As Department
From HumanResources.Department

Select GETDATE()
Select DATEADD(mm,3,GETDATE())
Select DATEADD(YY,3,GETDATE())
Select DATEADD(DD,3,GETDATE())
Select DATENAME(MONTH,GETDATE())

Select * from HumanResources.EmployeePayHistory
Select 'Rate' = MIN(Rate) from HumanResources.EmployeePayHistory
Select 'Maximum Rate' = max(Rate) From HumanResources.EmployeePayHistory
Select 'Sum' = SUM(DISTINCT Rate) From HumanResources.EmployeePayHistory
