﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AuthenticationLibrary
{
    public class Login : IUserValidation
    {
        public bool ValidateUser(string username, string password)
        {
            if (username.Equals("Samatha") && password.Equals("Samatha@123"))
                return true;
            else
                return false;
        }
    }
}
