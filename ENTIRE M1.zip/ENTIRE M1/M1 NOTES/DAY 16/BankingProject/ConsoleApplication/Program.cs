﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");

using AuthenticationLibrary;
using ConsoleApplication;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

class Program
{
    static void Main(string[] args)
    {
        Host.CreateDefaultBuilder()
         .ConfigureServices(ConfigureServices)
         .ConfigureServices(services => services.AddSingleton<Class1>())
         .Build()
         .Services
         .GetService<Class1>()
         .DisplayResult();
    }

    //Dependeny Container
    //Where we register all our dependencies of this project
    private static void ConfigureServices(HostBuilderContext hostContext, IServiceCollection services)
    {
        services.AddSingleton<IUserValidation, Login>();
    }
}
