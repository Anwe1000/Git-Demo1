﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CalculatorLibrary;

namespace Day16
{
    public class ClientCalculator
    {
        int num1, num2, result;
        Calculator obj;

        public ClientCalculator()
        {
            obj = new Calculator();
        }

        public void GetNumbers()
        {
            Console.WriteLine("Enter a number");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter a number");
            num2 = Convert.ToInt32(Console.ReadLine());

        }

        public void DisplayResult()
        {
            result = obj.Add(num1, num2);
            Console.WriteLine($"{num1} + {num2} = {result}");
        }
    }
}
