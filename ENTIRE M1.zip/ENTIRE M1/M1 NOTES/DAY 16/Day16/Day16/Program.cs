﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");

using Day16;


ClientCalculator calculator = new ClientCalculator();
calculator.GetNumbers();
calculator.DisplayResult();
