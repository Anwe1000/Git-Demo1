Create Database OrganizationDB

use OrganizationDB

Create Table Department
(
Deptid int Primary Key identity(1000,100),
DeptName varchar(50) not null,
Hod varchar(50) not null
)

Create Table Employee
(
EmployeeID int identity(1,1) not null,
FirstName varchar(50) not null,
LastName varchar(50) not null,
DepartmentID int null,
CONSTRAINT PK_EmployeeID PRIMARY KEY(EmployeeID),
CONSTRAINT FK_Employee_Department FOREIGN KEY(DepartmentID)
REFERENCES Department(Deptid)
)

insert into Department(DeptName,Hod) Values('Sales','Sam')
insert into Department(DeptName,Hod) Values('Accounts','Priyanka')
insert into Department(DeptName,Hod) Values('Marketing','Smruthi')
insert into Department(DeptName,Hod) Values('IT','Rekha')
insert into Department(DeptName,Hod) Values('Testing','Raghu')

insert into Employee(FirstName,LastName,DepartmentID)
Values('Samatha','Ramakrishna', Null)
insert into Employee(FirstName,LastName,DepartmentID) values('Samadrita','Chaterjee',Null)
insert into Employee(FirstName,LastName,DepartmentID) values('Supriya','Karn',Null)
insert into Employee(FirstName,LastName,DepartmentID) values('Margana','Neelima',Null)
insert into Employee(FirstName,LastName,DepartmentID) values('Rimpa','Satpathi',Null)
insert into Employee(FirstName,LastName,DepartmentID) values('Krishita','Viroja',Null)
insert into Employee(FirstName,LastName,DepartmentID) values('Priyanka','Kanubai Sagar',Null)
insert into Employee(FirstName,LastName,DepartmentID) values('Shruti','Kumari',Null)
insert into Employee(FirstName,LastName,DepartmentID) values('Smruthi','KalpanaDutta',Null)
insert into Employee(FirstName,LastName,DepartmentID) values('Gadde','Apoorva',Null)

Select * from Department

Select * from Employee

Select e1.EmployeeID,e1.FirstName,d1.Deptid,d1.DeptName
from Employee e1 Join Department d1
on d1.Deptid = e1.DepartmentID

select e1.EmployeeID,e1.FirstName,d1.Deptid,d1.DeptName
from Employee e1 left outer Join Department d1
on d1.Deptid = e1.DepartmentID

select e1.EmployeeID,E1.FirstName,d1.Deptid,d1.DeptName
from Employee e1 right outer join Department d1
on d1.Deptid = e1.DepartmentID

--Equi join--
select * from Employee  Join Department
on Employee.DepartmentID = Department.Deptid


create table EmpTable
(
empid int primary key,
empname varchar(50),
managerid int
)

insert into EmpTable values(101,'John Doe',100)
insert into EmpTable values(102,'Jane Smith',101)
insert into EmpTable values(103,'Joseph Reid',104)
insert into EmpTable values(104,'Nick Adams',105)
insert into EmpTable values(105,'Isabel Archer',102)

Select * from EmpTable

SELECT emp.empname as employee, mng.empname as manager
FROM EmpTable emp JOIN EmpTable mng ON
emp.managerid = mng.empid
