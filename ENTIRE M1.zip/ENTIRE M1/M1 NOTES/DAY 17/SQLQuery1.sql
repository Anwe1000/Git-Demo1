
GO
CREATE DATABASE MyDB           
ON PRIMARY
 ( NAME='MyDB_Primary',
   FILENAME=
      'C:\Data\MyDB_Primary.mdf',
   SIZE=4MB,
   MAXSIZE=10MB,
   FILEGROWTH=1MB),
FILEGROUP MyDB_FG1
 ( NAME = 'MyDB_FG1_Dat1',
   FILENAME =
      'C:\Data\MyDB_FG1_1.ndf',
   SIZE = 1MB,
   MAXSIZE=10MB,
   FILEGROWTH=1MB),
 ( NAME = 'MyDB_FG1_Dat2',
   FILENAME =
      'C:\Data\MyDB_FG1_2.ndf',
   SIZE = 1MB,
   MAXSIZE=10MB,
   FILEGROWTH=1MB)
LOG ON
( NAME='MyDB_log',
   FILENAME =
      'C:\Data\MyDB.ldf',
   SIZE=1MB,
   MAXSIZE=10MB,
   FILEGROWTH=1MB)
GO

Drop Database  MyDB

Create table Student
(
id int primary key,
Name varchar(50) not null,
Marks int check(marks > 0 and marks < 100) 
)

insert into Student values(1,'Anwesa',99)
insert into Student(id,Name) values(2,'TestStudent2')

select * from Student 

Create table Employee
(
empid int primary key identity(1,1),
name varchar(50) not null,
salary money check(salary > 35000),
designation varchar(50) null,
department varchar(50) default 'training'
)

insert into Employee(name,salary) values('Samatha',42000)
insert into Employee(name,salary,designation,department) values('Anwesa',50000,'Trainer','IT')

select * from Employee

