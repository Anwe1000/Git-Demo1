select * from Employee

alter table Employee
add emailID varchar(50) unique

insert into Employee(name,salary,designation,department,emailid)
values('Bandita',52000,'Manager','IT','bandita@gmail.com')

drop index Employee.UQ__Employee__87355E53FB01CC03