create table Product
(
id int,
Name varchar(50) not null,
price money check(price > 500 and price < 1000),
category varchar(50) check(category in ('Toys','Books','Electronics'))
)

sp_help Product

insert into Product(id,Name,price,category) values(1,'Alchemist',700,'Books')
insert into Product(id,Name,price,category) values(2,'Soft Toy',800,'Toys')
insert into Product(id,Name,price,category) values(3,'Digital Watch',600,'Electronics')
insert into Product(id,Name,price,category) values(4,'Feluda Series',800,'Books')

Select * from Product

drop Table Product

Alter Table Product 
drop column id

alter table Product
add Id int Primary key identity(100,100)

insert into Product(Name,price,category) values('Led Bulb',800,'Electronics')

-------------------------------- ANOTHER PROGRAM -----------------------------------------------------------

create table Category
(
categoryId int identity(1,1) Primary key not null,
Name varchar(50)
)

Create table Product2
(
prodid int identity(100,100),
Name varchar(50),
catid int,
price money,
CONSTRAINT PK_prodid Primary Key(prodid),
CONSTRAINT FK_Product2_Category FOREIGN KEY(catid)
REFERENCES Category(categoryId)
)

insert into Category(Name) values('Toys')
insert into Category(Name) values('Electronics')
insert into Category(Name) values('Accessories')
insert into Category(Name) values('Crockery')

insert into Product2(Name,catid,price) values('Feluda Series',1,400)
insert into Product2(Name,catid,price) values('Feluda Series',2,400)
insert into Product2(Name,catid,price) values('Feluda Series',3,400)
insert into Product2(Name,catid,price) values('Feluda Series',4,400)

Select * from Category

Select * from Product2


