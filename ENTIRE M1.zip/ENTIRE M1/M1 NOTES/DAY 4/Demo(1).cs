﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
 class Demo
 {
public void Add(int a, int b)
    {
        Console.WriteLine($"{a} + {b} = {a + b}");
}
    public void Add(int a, int b, int c)
    {
        Console.WriteLine($"{a} + {b} + {c}= {a + b + c}");
    }
    public void Add(string a, int b)
    {
        Console.WriteLine($"{a} + {b} = {a + b}");
    }


}
}
