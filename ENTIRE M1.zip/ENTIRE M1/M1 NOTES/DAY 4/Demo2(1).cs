﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Demo2
    {
        int productid;
        string productname;
        float productprice;

        public void GetDetails()
        {
            Console.WriteLine("Enter productid");
            productid = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter productname");
            productname = Console.ReadLine();
            Console.WriteLine("Enter product price");
            productprice = Convert.ToSingle(Console.ReadLine());
        }

        public void Print(int pid, string pname, float price)
        {
            Console.WriteLine($"Product id : {pid} ProductName : {pname} Productprice : {price}");
        }

        public void Display()
        {
            Print(pname:productname, price: productprice, pid : productid);
        }

    }
}
