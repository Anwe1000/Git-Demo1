﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day7_Inheritence
{

    // BASIC INHERITENCE PROGRAM
    internal class Child : Parent
    {
        int num1;

        public Child()
        {
            Console.WriteLine("Constructor of Child");
            num1 = 20;
        }

        public void Function2()
        {
            base.Function1();
            Console.WriteLine("I am child class of function 2");
            Console.WriteLine($"Num = {num}, Name = {name}");
        }
    }
}
