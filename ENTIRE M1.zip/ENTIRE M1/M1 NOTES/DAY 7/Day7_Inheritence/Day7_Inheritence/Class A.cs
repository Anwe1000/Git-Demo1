﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day7_Inheritence
{
    internal class Class_A
    {
        int num1;

        public Class_A(int num1)
        {
            this.num1 = num1;
            Console.WriteLine("Constructor of Class A");
        }

        public void Display()
        {
            Console.WriteLine($"Num of Class A = {num1}");
        }
    }
}
