﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day7_Inheritence
{
    internal class Class_B : Class_A
    {
        int num2;
        
        public Class_B(int num1, int num2) : base(num1)
        {
            this.num2 = num2;
            Console.WriteLine("Constructor of Class B");
        }

        public void Display2()
        {
            base.Display();
            Console.WriteLine($"Num 2 of Class B = {num2}");
        }
    }
}
