﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day7_Inheritence
{

    // BASIC INHERITENCE PROGRAM
    internal class Parent
    {
        protected int num;
        protected string name;

        public Parent()
        {
            Console.WriteLine("Default Constructor of Parent");
            num = 10;
            name = "an";
        }

        protected void Function1()
        {
            Console.WriteLine("Function 1 of Parent Constructor !");
        }
    }
}
