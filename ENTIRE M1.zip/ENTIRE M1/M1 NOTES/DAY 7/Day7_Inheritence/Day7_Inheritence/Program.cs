﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");

using Day7_Inheritence;

// BASIC INHERITENCE PROGRAM 

//Child obj = new Child();
//obj.Function2();


// PASSING DATA FROM CHILD CONSTRUCTOR TO PARENT CONSTRUCTOR

//Class_C obj = new Class_C(40, 50, 60);
//obj.Display3();

// VIRTUAL , VOID AND SEALED CLASS IN INHERITENCE

//VirtualSealedChild2 c = new VirtualSealedChild2();
//c.Display();

// SHADOWING

//ShadowChild sc = new ShadowChild();
//sc.Display();

