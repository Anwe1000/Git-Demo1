﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day7_Inheritence
{
    internal class ShadowChild : ShadowingDemo
    {
        //Shadowing
        public new void Display()
        {
            Console.WriteLine("This is Shadowing");
        }
    }
}
