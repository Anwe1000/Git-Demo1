﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day7_Inheritence
{
    internal class ShadowingDemo
    {
        public void Display()
        {
            Console.WriteLine("This is Parent Class!");
        }
    }
}
