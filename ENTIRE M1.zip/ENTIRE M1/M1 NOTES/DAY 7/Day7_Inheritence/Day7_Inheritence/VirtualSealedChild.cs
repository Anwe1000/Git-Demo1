﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day7_Inheritence
{
    internal class VirtualSealedChild : VirtualSealedVoidDemo
    {
        public override void Display()
        {
            base.Display();
            Console.WriteLine("Child overrides the parent virtual method");
        }
    }
}
