﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day7_Inheritence
{
    internal class VirtualSealedChild2 : VirtualSealedChild
    {
        public override void Display()
        {
            base.Display();
            Console.WriteLine("Child 2 overrides the Display method");
        }
    }
}
