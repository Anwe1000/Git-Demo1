﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day7_Inheritence
{
    internal class VirtualSealedVoidDemo
    {
        public virtual void Display()
        {
            Console.WriteLine("This is virtual class, which can be modified by the inherited Child class");
        }
    }
}
