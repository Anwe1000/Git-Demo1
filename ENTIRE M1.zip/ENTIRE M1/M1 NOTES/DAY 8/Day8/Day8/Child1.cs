﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day8
{
    internal class Child1 : Parent
    {
        public override void SayHello()
        {
            Console.WriteLine("Say Hello of Child1");
        }
    }
}
