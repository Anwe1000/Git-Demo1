﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace Day8
{
    internal class Circle : InterfaceDemo
    {
        float area;
        const float pie = 3.14f;
        float radius;

        public void CalculateArea()
        {
            area = pie * radius * radius;
        }

        public void DisplayDetails()
        {
            Console.WriteLine($"Area is : {area}");
        }

        public void GetDetails()
        {
            Console.WriteLine("Enter the radius");
            radius = Convert.ToSingle(Console.ReadLine());
        }
    }
}
