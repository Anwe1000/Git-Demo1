﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day8
{
    internal class Class2 : Parent
    {
        public override void SayHello()
        {
            Console.WriteLine("Say hello of child 2");   
        }
    }
}
