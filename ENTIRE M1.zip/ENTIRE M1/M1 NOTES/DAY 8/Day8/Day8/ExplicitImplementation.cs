﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day8
{
    internal class ExplicitImplementation : Interface1, Interface2
    {
        void Interface1.Display()
        {
            Console.WriteLine("Interface 1");
        }

        void Interface2.Display()
        {
            Console.WriteLine("Interface 2");
        }
    }
}
