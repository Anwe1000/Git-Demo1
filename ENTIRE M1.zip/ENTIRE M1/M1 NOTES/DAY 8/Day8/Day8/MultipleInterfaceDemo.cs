﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day8
{
    internal class MultipleInterfaceDemo : MultipleInterface, Multiple
    {
        public void Function1()
        {
            Console.WriteLine("This is Function 1");
        }

        public void Function2() 
        {
            Console.WriteLine("This is Function 2");
        }
    }
}
