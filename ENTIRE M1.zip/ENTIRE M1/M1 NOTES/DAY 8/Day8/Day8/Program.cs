﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using Day8;

//Parent obj = new Child1();
//obj.SayHello();
//obj.SayHello();


//// Interface Demo

//Circle obj = new Circle();
//obj.GetDetails();
//obj.CalculateArea();
//obj.DisplayDetails();
//InterfaceDemo id1 = new Circle();
//id1.GetDetails();
//id1.CalculateArea();
//id1.DisplayDetails();

//InterfaceDemo id2 = new Rectangle();
//id2.GetDetails();
//id2.CalculateArea();
//id2.DisplayDetails();


//InterfaceDemo id3 = new Square();
//id3.GetDetails();
//id3.CalculateArea();
//id3.DisplayDetails();

//// Multiple Interface

//MultipleInterfaceDemo md = new MultipleInterfaceDemo();
//md.Function1();
//md.Function2();

/// Explicit Interface

ExplicitImplementation ic = new ExplicitImplementation();
