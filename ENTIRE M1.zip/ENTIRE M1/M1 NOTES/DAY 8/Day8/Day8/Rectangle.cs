﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day8
{
    internal class Rectangle : InterfaceDemo
    {
       float length;
        float breadth;
        float area;

        public void CalculateArea()
        {
            area = length * breadth;
        }

        public void GetDetails()
        {
            Console.WriteLine("Enter the length");
            Console.WriteLine("Enter the breadth");

            length = Convert.ToSingle(Console.ReadLine());
            breadth = Convert.ToSingle(Console.ReadLine()); 
        }

        public void DisplayDetails()
        {
            Console.WriteLine($"Area is : {area}");
        }
    }
}
