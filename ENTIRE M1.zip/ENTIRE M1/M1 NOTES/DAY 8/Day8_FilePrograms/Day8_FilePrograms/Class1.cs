﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Day8_FilePrograms
{
    internal class Class1
    {
        FileStream fs; // provides the methods and properties for writing and reading files in a program

        public Class1()
        {
            fs = new FileStream("Student.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
            //fs = new FileStream(@"D:\day3\StudentsList.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
            //fs = new FileStream("D:/day3/StudentsList.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
            //fs = new FileStream("D:\\day3\\StudentsList.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
        }
    }
}
