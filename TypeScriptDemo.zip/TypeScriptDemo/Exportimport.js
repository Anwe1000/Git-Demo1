"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var index_1 = require("./index");
var index_2 = require("./index");
(0, index_1.sayHello)("Samatha");
(0, index_2.Add)(10, 20);
