import {sayHello} from "./index"
import { Add } from "./index"

sayHello("Samatha")
Add(10,20)