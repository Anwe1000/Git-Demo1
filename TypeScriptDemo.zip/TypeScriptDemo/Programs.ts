// 1)Create a function which accepts your name and prints it in reverse
//----------------------------------------------------------------------

// SOLUTION 1 

// var str=""

// function ReverseString(name:string)
// {
//     for(let i = name.length-1; i >= 0; i--)
//     {
//         str += name[i]
//     }

//     console.log(`The reversed string is : ${str}`)
// }

// ReverseString("Anwesa")


// 2)Create a function take three numbers as parameters and display the greatest
//-------------------------------------------------------------------------------

//SOLUTION 2

// function GreatestofAll(a:number, b:number, c:number)
// {
//     if(a > b && a > c)
//     {
//         console.log(`a is greatest : ${a}`)
//     }
//     else if(b > a && b > c)
//     {
//         console.log(`b is greatest : ${b}`)
//     }
//     else
//     {
//         console.log(`c is greatest : ${c}`)
//     }
// }

// GreatestofAll(10,20,30)


//3)create a function which takes a alphabet and display whether it is vowel or not using switch case
// ---------------------------------------------------------------------------------------------------

//SOLUTION 3

// function Vowel(str:string)
// {
    
//     switch(str)
//     {
//         case 'a':
//             console.log(`Its a Vowel`)
//             break;

//             case 'e':
//                 console.log(`Its a Vowel`)
//                 break;

//                 case 'i':
//                     console.log(`Its a Vowel`)
//                     break;

//                     case 'o':
//                         console.log(`Its a Vowel`)
//                         break;

//                         case 'u':
//                             console.log(`Its a Vowel`)
//                             break;

//     }
// }

// Vowel('a')


//4)create a function which takes a alphabet and display whether it is vowel or not using if else
//------------------------------------------------------------------------------------------------

//SOLUTION 4

// function IfVowel(str:string) : string
// {
//     str = str.toLocaleLowerCase()

//     if(str == 'a' || str == 'e' || str == 'i' || str == 'o' || str == 'u')
//     {
//         return `It is a vowel ${str}`
//     }
//     else
//     {
//         return 'it is not  vowel'
//     }
// }

// var a = IfVowel('a')
// console.log(a)


//5)create a function which accepts username and password . 
//check username is 'Administrator' and password is 'Admin@123' then return true else return false.
//call the function in another function and display login successful or login failed
//---------------------------------------------------------------------------------------------------

//SOLUTION 5

// function Check(Username:string, Password:string) : boolean
// {
//     if(Username == "Administrator" && Password == "Admin@123")
//     {
//         return true;
//     }
//     else
//     {
//         return false;
//     }
// }

// Check("Administrator", "Admin@123") 

// function DoubleCheck() : string
// {
//     if(!Check("Administrator", "Admin@123"))
//     {
//         return `Login Failed`;
//     }
//     else
//     {
//         return `Login Successful`;
//     }
// }

// var result2 = DoubleCheck()
// console.log(result2)

//_________________________________________________________________________________


// USING ONLY ONE FUNCTION

// function Check(Username:string, Password:string) : boolean
// {
//     if(Username == "Administrator" && Password == "Admin@123")
//     {
//         return true;
//     }
//     else
//     {
//         return false;
//     }
// }

// var res2 = Check("Administrator", "Admin@123")
// console.log(res2)


