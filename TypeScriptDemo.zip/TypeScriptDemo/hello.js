//console.log('hello world')
var trainerName = "Anwesa";
console.log("Name = ".concat(trainerName));
var studentName = "Robert";
console.log("Name : ".concat(trainerName));
var organizationName;
organizationName = "Capgemini";
console.log("Name : ".concat(organizationName));
