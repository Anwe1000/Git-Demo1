//console.log('hello world')

var trainerName:string = "Anwesa"
console.log(`Name = ${trainerName}`)

var studentName = "Robert"
console.log(`Name : ${trainerName}`)

var organizationName:string
organizationName = "Capgemini"
console.log(`Name : ${organizationName}`)

