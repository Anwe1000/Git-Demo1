"use strict";
// function sayHello(name:string)
// {
//     console.log(`hello ${name}`)
// }
Object.defineProperty(exports, "__esModule", { value: true });
exports.Add = exports.sayHello = void 0;
// sayHello('MyName')
// function Add(a:number, b:number) : number
// {
//     return a + b;
// }
// var result = Add(10,20)
// console.log(`Result : ${result}`)
function sayHello(name) {
    console.log("hello ".concat(name));
}
exports.sayHello = sayHello;
sayHello('MyName');
function Add(a, b) {
    return a + b;
}
exports.Add = Add;
var result = Add(10, 20);
console.log("Result : ".concat(result));
