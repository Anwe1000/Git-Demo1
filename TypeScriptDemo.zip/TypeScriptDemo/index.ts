// function sayHello(name:string)
// {
//     console.log(`hello ${name}`)
// }

// sayHello('MyName')

// function Add(a:number, b:number) : number
// {
//     return a + b;
// }

// var result = Add(10,20)
// console.log(`Result : ${result}`)


export function sayHello(name:string)
{
    console.log(`hello ${name}`)
}

sayHello('MyName')

export function Add(a:number, b:number) : number
{
    return a + b;
}

var result = Add(10,20)
console.log(`Result : ${result}`)